#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct 
{
    char content[1000];
    int file;
}DATA;

typedef struct {
    char content[1000];
    int files[10];
}finalSolution;

int main(int argc, char **argv)
{
    FILE *f[10];
    char piece[1000], word[1000], wordaux[1000], *p;
    int i, j, k, t, n = 0, found, ok;
    DATA suggestions[1000], aux;
    finalSolution sol[100];
    
    for (i = 1; i < argc; i++)
    {
        if ((f[i] = fopen(argv[i], "r")) == NULL)
        {
            printf("Fisierul nu s-a deschis corect!\n");
            exit(1);
        }

    }

    fscanf(stdin, "%s", piece);
    while (strcmp(piece, "/exit") != 0)
    {
        n=0; found=0; 
        // suggestions=(DATA*)malloc(sizeof(DATA));
        // if(suggestions == NULL)
        // printf("Alocarea nu a reusit!");
        for (i = 1; i < argc; i++)
        {
            while(fscanf(f[i], "%s", word) != EOF)
            {
                for(j = 0; word[j] != '\0'; ++j)
                {
                    while (!( (word[j] >= 'a' && word[j] <= 'z') || (word[j] >= 'A' && word[j] <= 'Z') || word[j] == '\0' || word[j] =='-' ) )
                    {
                        for(k = j; word[k] != '\0'; ++k)
                        {
                            word[k] = word[k+1];
                        }
                        word[k] = '\0';
                    }
                }
                        

                for(j=0; j< strlen(word); j++)
                    if(word[j]<97 && word[j] != '-')
                        word[j] += 32;
                
                strcpy(wordaux, word);
                p = strtok(wordaux, "-");
                while(p!=NULL)
                {
                    ok = 1;
                    for(j=0;j<strlen(piece); j++)
                    {
                        if(piece[j] != p[j])
                        {
                            ok = 0; 
                            break;
                        }
                    }
                    if(ok == 1)
                    {
                        strcpy(suggestions[n].content, word);
                        suggestions[n++].file = i;
                        found = 1;
                        // size=(sizeof(suggestions)+sizeof(DATA));
                        // suggestions = (DATA*)realloc(suggestions, size);
                        break;
                    }
                    p = strtok(NULL, "-");
                }

            }


            fseek(f[i], 0, SEEK_SET);
        }
        for(j=0; j<n-1; j++)
        for(k=j+1; k<n; k++)       
        {
            if(strcmp(suggestions[j].content, suggestions[k].content) > 0 )
            {
                aux = suggestions[j];
                suggestions[j] = suggestions[k];
                suggestions[k] = aux;
            }
            else if((strcmp(suggestions[j].content, suggestions[k].content) == 0) && (suggestions[j].file > suggestions[k].file))
            {
                aux = suggestions[j];
                suggestions[j] = suggestions[k];
                suggestions[k] = aux;
            }
        }
        if(found == 1){
            k=0; j=0;
            strcpy(sol[0].content, suggestions[0].content);
            for(i=1; i<argc; i++)
            sol[k].files[i] = 0;
            while(n)
            {
                if(strcmp(sol[k].content, suggestions[j].content)==0)
                {
                    sol[k].files[suggestions[j].file] = 1;
                    n--;     
                    j++;  
                }
                else
                {
                    k++;
                    for(i=1; i<argc; i++)
                    sol[k].files[i] = 0;
                    strcpy(sol[k].content, suggestions[j].content);
                    sol[k].files[suggestions[j].file] = 1;
                    j++;
                    n--; 
                }
            }

            t=0; 
            for(i=0; i<=k && t<5; i++)
            {
                t++;
                printf("%s : ", sol[i].content);
                for(j=1; j<argc; j++)
                {
                    if((sol[i].files[j]) == 1)
                    {
                        printf("%d ", j);
                    }
                }
                printf("\n");
            }

        printf("\n");
        }
        else if(found == 0)
        printf("No suggestions...\n\n");
        // free(suggestions);
        fscanf(stdin, "%s", piece);
    } 
    
    
 
    return 0;
}